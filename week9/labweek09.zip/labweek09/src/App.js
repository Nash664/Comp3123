import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>
          Welcome to Full Stack Development -1
        </h1>
        <h2>React JS Programming Week09 Lab exercise</h2>
        <h3>101472057</h3>
        <h4>Nashiruddin Feroz</h4>
       <h5>George Brown College, Toronto</h5>
      </header>
    </div>
  );
}

export default App;
